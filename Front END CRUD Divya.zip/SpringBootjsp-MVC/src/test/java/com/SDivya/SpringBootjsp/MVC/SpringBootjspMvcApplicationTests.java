package com.SDivya.SpringBootjsp.MVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootjspMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
