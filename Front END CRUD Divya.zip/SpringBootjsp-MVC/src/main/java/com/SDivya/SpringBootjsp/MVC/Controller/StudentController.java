package com.SDivya.SpringBootjsp.MVC.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.SDivya.SpringBootjsp.MVC.model.Student;

@Controller
public class StudentController {

	@Autowired
	SessionFactory sf;

	@RequestMapping("home")
	public String home() {
		return "home";
	}

	@RequestMapping("savepage")
	public String savepage() {
		return "save";
	}

	@PostMapping("/save")
	public Student saveData(Student student) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(student);
		t.commit();
		return student;
	}

	@RequestMapping("updatepage")
	public String updatepage() {
		return "update";
	}

	@PostMapping("update")
	public String updateData(Student student) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.update(student);
		t.commit();
		return "save";
	}

	@RequestMapping("deletepage")
	public String deletepage() {
		return "delete";
	}

	@RequestMapping("delete")
	public String deleteData(String id) {
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		Student ss=s.get(Student.class, id);
		s.delete(ss);
		t.commit();
		return "save";
	}

	@RequestMapping("viewtable")
	public String viewtable() {
		return "viewStudent";
	}

}
