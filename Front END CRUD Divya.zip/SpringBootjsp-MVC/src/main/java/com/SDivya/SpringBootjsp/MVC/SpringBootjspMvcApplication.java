package com.SDivya.SpringBootjsp.MVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootjspMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootjspMvcApplication.class, args);
		System.out.println("SpringBoot MVC");
	}

}
