package com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Service;

import com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Model.Order;

public interface IOrderService {

	public Order addOrder(Order order);

	public Order getOrder(Integer id);

	public Order updateOrder(Order order);

	public String deleteOrder(Integer id);

}
