package com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Repostory;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Model.Order;

@Repository
public interface OrderRepostory extends CrudRepository<Order, Integer> {

}
