package com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Model.Order;
import com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Repostory.OrderRepostory;

@Service
public class OrderService implements IOrderService{

	@Autowired
	private OrderRepostory orderRepostory;

	public OrderRepostory getOrderRepostory() {
		return orderRepostory;
	}

	public void setOrderRepostory(OrderRepostory orderRepostory) {
		this.orderRepostory = orderRepostory;
	}

	@Override
	public Order addOrder(Order order) {
		Order savedOrder=orderRepostory.save(order);
		return savedOrder;
	}

	@Override
	public Order getOrder(Integer id) {
	Optional<Order>	orderOptional=orderRepostory.findById(id);
		return orderOptional.orElse(null);
	}

	@Override
	public Order updateOrder(Order order) {
		Order orderFromDb = orderRepostory.findById(order.getId()).orElse(null);
		if (orderFromDb==null) {
			throw new RuntimeException("No such order Exisit");
		}
		orderFromDb.setName(order.getName());
		
		return orderRepostory.save(orderFromDb);
	}
	
	@Override
	public String deleteOrder(Integer id) {
		orderRepostory.deleteById(id);
		return "Deleted...";
	}
}
