package com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Model.Order;
import com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System.Service.IOrderService;

@RestController
@RequestMapping(path = "orders")
public class OrderController {

	@Autowired
	private IOrderService orderService;

	@PostMapping
	public @ResponseBody Order addOrder(@RequestBody Order order) {
		Order saveOrder = orderService.addOrder(order);
		return saveOrder;
	}

	@PutMapping
	public @ResponseBody Order updateOrder(@RequestBody Order order) {
		Order updatedOrder = orderService.updateOrder(order);
		return updatedOrder;
	}

	// single record

	@GetMapping(path = "/{id}")
	public @ResponseBody Order getOrder(@PathVariable Integer id) {
		return orderService.getOrder(id);
	}

	@DeleteMapping(path = "/{id}")
	public @ResponseBody String deleteOrder(@PathVariable Integer id) {
		return orderService.deleteOrder(id);
	}

	
	
	
	public IOrderService getOrderService() {
		return orderService;
	}

	public void setOrderService(IOrderService orderService) {
		this.orderService = orderService;
	}

}
