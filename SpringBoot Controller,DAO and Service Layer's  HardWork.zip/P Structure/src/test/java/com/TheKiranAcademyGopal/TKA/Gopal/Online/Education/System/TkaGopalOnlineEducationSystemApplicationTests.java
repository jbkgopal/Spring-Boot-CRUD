package com.TheKiranAcademyGopal.TKA.Gopal.Online.Education.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TkaGopalOnlineEducationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
