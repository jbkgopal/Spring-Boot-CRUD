package com.Gopal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Gopal.Pojo.Student;
import com.Gopal.Service.MyService;

@RestController
public class MyController {

	@Autowired
	private MyService myService;

	@GetMapping("showSingleStudentRecord/{id}")
	public String showSingleStudentRecord(@PathVariable int id) {
		return myService.showSingleStudentRecord(id);
	}

	@GetMapping("showMultipleStudentRecord")
	public String showMultipleStudentRecord() {
		return myService.showMultipleStudentRecord();
	}

	@PostMapping("insertSingleStudentRecord")
	public String insertSingleStudentRecord(@RequestBody Student student) {
		return myService.insertSingleStudentRecord(student);
	}

	@PostMapping("insertSingleRecordPath/{id}/{name}")
	public String insertAPI(@PathVariable int id, String name) {
		return myService.insertAPI(id, name);
	}

	@PostMapping("insertMultipleStudentRecord")
	public String insertMultipleStudentRecord(@RequestBody List<Student> list) {
		return myService.insertMultipleStudentRecord(list);
	}

	@PutMapping("updateSingleStudentRecord")
	public String updateSingleStudentRecord(@RequestBody Student student) {
		return myService.updateSingleStudentRecord(student);
	}

	@PutMapping("updateMultipleRecord")
	public String multipleupdate(@RequestBody List<Student> list) {
		return myService.multipleupdate(list);
	}

	@PatchMapping("partialSingleFieldUpdate/{id}/{name}")
	public String partialSingleFieldUpdate(@PathVariable int id, String name) {
		return myService.partialSingleFieldUpdate(id, name);
	}

	@PatchMapping("partialMultipleFieldUpdate/{id}/{name}")
	public String partialMultipleFieldUpdate(@PathVariable int id, String name, String city) {
		return myService.partialMultipleFieldUpdate(id, name, city);
	}

	@DeleteMapping("deleteSingleStudentRecord/{id}")
	public String deleteSingleStudentRecord(@PathVariable int id) {
		return myService.deleteSingleStudentRecord(id);
	}

	@DeleteMapping("deleteMultipleRecord")
	public String deleteAllStudentRecord() {
		return myService.deleteAllStudentRecord();
	}

}
