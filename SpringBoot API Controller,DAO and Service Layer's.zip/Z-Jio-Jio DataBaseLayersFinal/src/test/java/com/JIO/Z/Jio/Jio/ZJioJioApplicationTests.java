package com.JIO.Z.Jio.Jio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZJioJioApplicationTests {

	@Test
	void contextLoads() {
	}

}
