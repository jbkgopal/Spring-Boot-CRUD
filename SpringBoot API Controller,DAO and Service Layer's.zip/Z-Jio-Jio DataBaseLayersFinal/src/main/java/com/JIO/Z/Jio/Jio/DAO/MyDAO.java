package com.JIO.Z.Jio.Jio.DAO;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.JIO.Z.Jio.Jio.Pojo.Student;

@Repository
public class MyDAO {

	@Autowired
	SessionFactory sf;
	
	public String showSingleStudentRecord(int id) {
		// Database interaction code
		Session s=sf.openSession();
		Student ss=s.get(Student.class, id);
		return "Show Single Student Record \n"+ss;
	}
}
