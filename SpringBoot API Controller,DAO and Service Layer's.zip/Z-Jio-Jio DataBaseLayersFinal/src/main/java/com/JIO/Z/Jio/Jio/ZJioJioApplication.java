package com.JIO.Z.Jio.Jio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZJioJioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZJioJioApplication.class, args);
		System.out.println("HEllo");
	}

}
