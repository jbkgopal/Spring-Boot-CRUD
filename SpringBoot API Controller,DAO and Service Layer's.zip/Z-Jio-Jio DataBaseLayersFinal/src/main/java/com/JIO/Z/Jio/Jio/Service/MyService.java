package com.JIO.Z.Jio.Jio.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JIO.Z.Jio.Jio.DAO.MyDAO;

@Service
public class MyService {

	@Autowired
	private MyDAO myDAO;

	public String showSingleStudentRecord(int id) {
		return myDAO.showSingleStudentRecord(id);
	}
}
